import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'news-page',
    loadChildren: () => import('./news-page/news-page.module').then( m => m.NewsPagePageModule)
  },
  {
    path: 'sports-news',
    loadChildren: () => import('./sports-news/sports-news.module').then( m => m.SportsNewsPageModule)
  },
  {
    path: 'tech-news',
    loadChildren: () => import('./tech-news/tech-news.module').then( m => m.TechNewsPageModule)
  },
  {
    path: 'entertainment-news',
    loadChildren: () => import('./entertainment-news/entertainment-news.module').then( m => m.EntertainmentNewsPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
