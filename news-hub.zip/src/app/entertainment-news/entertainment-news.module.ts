import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EntertainmentNewsPageRoutingModule } from './entertainment-news-routing.module';

import { EntertainmentNewsPage } from './entertainment-news.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EntertainmentNewsPageRoutingModule
  ],
  declarations: [EntertainmentNewsPage]
})
export class EntertainmentNewsPageModule {}
