import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EntertainmentNewsPage } from './entertainment-news.page';

const routes: Routes = [
  {
    path: '',
    component: EntertainmentNewsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EntertainmentNewsPageRoutingModule {}
