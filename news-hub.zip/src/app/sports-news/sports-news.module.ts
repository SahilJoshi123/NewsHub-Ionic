import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SportsNewsPageRoutingModule } from './sports-news-routing.module';

import { SportsNewsPage } from './sports-news.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SportsNewsPageRoutingModule
  ],
  declarations: [SportsNewsPage]
})
export class SportsNewsPageModule {}
