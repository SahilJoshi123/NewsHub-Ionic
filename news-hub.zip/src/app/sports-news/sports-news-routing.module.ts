import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SportsNewsPage } from './sports-news.page';

const routes: Routes = [
  {
    path: '',
    component: SportsNewsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SportsNewsPageRoutingModule {}
