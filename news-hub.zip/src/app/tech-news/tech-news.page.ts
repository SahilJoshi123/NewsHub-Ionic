import { Component, OnInit } from '@angular/core';
import { NewsService } from '../news.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tech-news',
  templateUrl: './tech-news.page.html',
  styleUrls: ['./tech-news.page.scss'],
})
export class TechNewsPage implements OnInit {

  constructor(private newsService: NewsService, private router: Router) {}

  data: any;
  ngOnInit() {
    this.newsService.getData("top-headlines?country=in&category=technology").subscribe(data => {
      console.log(data);
      this.data = data;
    });
  }

  onClick(article: any){
    this.newsService.setCurrentArticle(article)
    this.router.navigate(['/news-page'])
  }

}
